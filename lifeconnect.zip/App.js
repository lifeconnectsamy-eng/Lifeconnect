import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

function HomeScreen() {
  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
      <Text>Acasă — Feed LifeConnect</Text>
    </View>
  );
}
function ChatScreen() {
  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
      <Text>Chat — mesaje private și live chat</Text>
    </View>
  );
}
function LiveScreen() {
  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
      <Text>Live — alege Studio TV / Talk-show / News</Text>
    </View>
  );
}
function NotifScreen() {
  return (
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
      <Text>Notificări</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{headerShown:false}}>
        <Tab.Screen name="Acasă" component={HomeScreen}/>
        <Tab.Screen name="Chat" component={ChatScreen}/>
        <Tab.Screen name="Live" component={LiveScreen}/>
        <Tab.Screen name="Notificări" component={NotifScreen}/>
      </Tab.Navigator>
    </NavigationContainer>
  );
}